JOURNAL DE MON TÉLÉPHONE — compilation dans le cloud depuis un téléphone

AUCUN ordinateur ni application de compilation à installer.

1. Dans le navigateur du téléphone, crée/connecte-toi à un compte GitHub : https://github.com
2. Crée un nouveau dépôt (repository) nommé JournalTelephone. Pour faciliter le tutoriel, coche Public; n'ajoute pas de README ni de licence.
3. Décompresse ce ZIP sur ton téléphone avec l'application Fichiers. Dans le dépôt GitHub, utilise Add file > Upload files et envoie TOUS les fichiers contenus dans le dossier JournalTelephone, y compris le dossier caché .github/workflows si l'interface le permet. Si l'envoi des dossiers est compliqué sur mobile, il faudra passer par GitHub Codespaces ou un autre service cloud.
4. Ouvre l'onglet Actions du dépôt. Autorise les actions si GitHub le demande. Choisis « Construire APK Android », puis Run workflow.
5. Quand l'exécution est terminée en vert, ouvre le résultat et télécharge l'artefact « JournalTelephone-debug-apk ». Il contient app-debug.apk.
6. Installe l'APK téléchargé. Android peut demander d'autoriser l'installation depuis le navigateur ou l'application Fichiers.

Le build peut échouer si le projet Kotlin contient une erreur; dans ce cas, envoie le message d'erreur pour correction.
Au premier lancement, l'application demandera l'accès Android aux données d'utilisation pour afficher les statistiques.
