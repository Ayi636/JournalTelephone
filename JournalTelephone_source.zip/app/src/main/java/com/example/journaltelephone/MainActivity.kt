package com.example.journaltelephone

import android.app.Activity
import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class Session(val pkg: String, val start: Long, var end: Long)

class MainActivity : Activity() {

    private var day = startOf(System.currentTimeMillis())
    private lateinit var root: LinearLayout
    private var report = ""
    private val hm = SimpleDateFormat("HH:mm", Locale.FRANCE)
    private val dateFmt = SimpleDateFormat("EEEE d MMMM", Locale.FRANCE)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sv = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(40), dp(16), dp(32))
        }
        sv.addView(root)
        setContentView(sv)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun startOf(ts: Long): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = ts
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    private fun hasAccess(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = ops.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun label(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }

    private fun dur(ms: Long): String {
        val m = (ms / 60000).toInt()
        if (m < 1) return "${ms / 1000} s"
        return if (m >= 60) "${m / 60} h ${m % 60} min" else "$m min"
    }

    private fun text(s: String, size: Float = 16f, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = s
            textSize = size
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(6), 0, dp(6))
        }

    // Lit les évènements d'utilisation que le système Android a déjà enregistrés.
    private fun loadSessions(): List<Session> {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val from = day
        val to = minOf(day + 86400000L, System.currentTimeMillis())
        val events = usm.queryEvents(from, to)
        val e = UsageEvents.Event()
        val open = HashMap<String, Long>()
        val raw = ArrayList<Session>()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            when (e.eventType) {
                UsageEvents.Event.ACTIVITY_RESUMED -> open[e.packageName] = e.timeStamp
                UsageEvents.Event.ACTIVITY_PAUSED -> {
                    val s = open.remove(e.packageName)
                    if (s != null) raw.add(Session(e.packageName, s, e.timeStamp))
                }
            }
        }
        for ((p, s) in open) raw.add(Session(p, s, to))
        raw.sortBy { it.start }
        // Fusionne les sessions proches de la même appli
        val merged = ArrayList<Session>()
        for (s in raw) {
            val last = merged.lastOrNull()
            if (last != null && last.pkg == s.pkg && s.start - last.end < 30000) last.end = s.end
            else merged.add(Session(s.pkg, s.start, s.end))
        }
        return merged.filter { it.end - it.start >= 5000 }
    }

    private fun render() {
        root.removeAllViews()
        root.addView(text("Journal de mon téléphone", 24f, true))

        if (!hasAccess()) {
            root.addView(text("Pour lister ce que tu fais sur ton téléphone, l'appli doit accéder aux données d'utilisation. Active-la pour cette appli dans la page qui s'ouvre."))
            root.addView(Button(this).apply {
                text = "Autoriser l'accès"
                setOnClickListener { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
            })
            return
        }

        val nav = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val prev = Button(this).apply { text = "‹"; setOnClickListener { day -= 86400000L; render() } }
        val next = Button(this).apply {
            text = "›"
            isEnabled = day < startOf(System.currentTimeMillis())
            setOnClickListener { day += 86400000L; render() }
        }
        val title = text(dateFmt.format(Date(day)).replaceFirstChar { it.uppercase() }, 18f, true)
        title.gravity = Gravity.CENTER
        nav.addView(prev)
        nav.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        nav.addView(next)
        root.addView(nav)

        val sessions = loadSessions()
        if (sessions.isEmpty()) {
            root.addView(text("Aucune activité enregistrée pour ce jour. Android ne garde l'historique que quelques jours."))
            return
        }

        val totals = HashMap<String, Long>()
        for (s in sessions) totals[s.pkg] = (totals[s.pkg] ?: 0L) + (s.end - s.start)
        val total = totals.values.sum()

        val sb = StringBuilder("Journal du ${dateFmt.format(Date(day))}\n\n")

        root.addView(text("Temps d'écran : ${dur(total)}", 18f, true))
        root.addView(text("Applis les plus utilisées", 16f, true))
        for ((p, t) in totals.entries.sortedByDescending { it.value }.take(8)) {
            root.addView(text("${label(p)} : ${dur(t)}"))
        }

        root.addView(text("Chronologie", 16f, true))
        for (s in sessions) {
            val line = "${hm.format(Date(s.start))} – ${hm.format(Date(s.end))}  ${label(s.pkg)} (${dur(s.end - s.start)})"
            root.addView(text(line))
            sb.append(line).append('\n')
        }
        sb.append("\nTemps d'écran total : ${dur(total)}\n")
        report = sb.toString()

        root.addView(Button(this).apply {
            text = "Copier le rapport"
            setOnClickListener {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("rapport", report))
                Toast.makeText(this@MainActivity, "Rapport copié", Toast.LENGTH_SHORT).show()
            }
        })
    }
}
