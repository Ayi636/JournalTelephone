package com.example.journaltelephone

import android.app.Activity
import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class Session(val pkg: String, val start: Long, var end: Long)

class MainActivity : Activity() {
    private var day = startOf(System.currentTimeMillis())
    private lateinit var root: LinearLayout
    private var report = ""
    private val hm = SimpleDateFormat("HH:mm", Locale.FRANCE)
    private val dateFmt = SimpleDateFormat("EEEE d MMMM", Locale.FRANCE)

    private val bg = Color.rgb(3, 10, 32)
    private val panel = Color.rgb(7, 22, 59)
    private val blue = Color.rgb(0, 105, 255)
    private val cyan = Color.rgb(45, 190, 255)
    private val white = Color.rgb(242, 247, 255)
    private val muted = Color.rgb(160, 187, 235)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0

        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(28))
        }
        scroll.addView(root)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun startOf(ts: Long): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = ts
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    private fun hasAccess(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = ops.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun label(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (_: Exception) { pkg }

    private fun dur(ms: Long): String {
        val m = (ms / 60000).toInt()
        if (m < 1) return "${ms / 1000} s"
        return if (m >= 60) "${m / 60} h ${m % 60} min" else "$m min"
    }

    private fun rounded(color: Int, stroke: Int = Color.TRANSPARENT, radius: Int = 22): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
        }

    private fun labelText(s: String, size: Float, color: Int = white, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = s
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            includeFontPadding = true
        }

    private fun addSpace(height: Int) {
        root.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(16), dp(18), dp(16))
        background = rounded(panel, Color.rgb(14, 62, 150))
    }

    private fun actionButton(caption: String, onClick: () -> Unit): Button =
        Button(this).apply {
            text = caption
            isAllCaps = false
            textSize = 15f
            setTextColor(Color.WHITE)
            background = rounded(blue, blue, 28)
            setOnClickListener { onClick() }
        }

    // Les événements d'utilisation sont fournis par Android après autorisation.
    private fun loadSessions(): List<Session> {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val from = day
        val to = minOf(day + 86400000L, System.currentTimeMillis())
        val events = usm.queryEvents(from, to)
        val e = UsageEvents.Event()
        val open = HashMap<String, Long>()
        val raw = ArrayList<Session>()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            when (e.eventType) {
                UsageEvents.Event.ACTIVITY_RESUMED -> open[e.packageName] = e.timeStamp
                UsageEvents.Event.ACTIVITY_PAUSED -> {
                    val s = open.remove(e.packageName)
                    if (s != null) raw.add(Session(e.packageName, s, e.timeStamp))
                }
            }
        }
        for ((p, s) in open) raw.add(Session(p, s, to))
        raw.sortBy { it.start }
        val merged = ArrayList<Session>()
        for (s in raw) {
            val last = merged.lastOrNull()
            if (last != null && last.pkg == s.pkg && s.start - last.end < 30000) last.end = s.end
            else merged.add(Session(s.pkg, s.start, s.end))
        }
        return merged.filter { it.end - it.start >= 5000 }
    }

    private fun render() {
        root.removeAllViews()

        val header = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            orientation = LinearLayout.HORIZONTAL
        }
        val logo = TextView(this).apply {
            text = "◉"
            textSize = 38f
            setTextColor(cyan)
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(9, 43, 112), blue, 18)
        }
        header.addView(logo, LinearLayout.LayoutParams(dp(58), dp(58)))
        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }
        titleBox.addView(labelText("Journal de mon", 21f, white, true))
        titleBox.addView(labelText("téléphone", 21f, cyan, true))
        header.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(labelText("✦", 30f, Color.rgb(255, 190, 35), true))
        root.addView(header)
        addSpace(24)

        val hero = card()
        hero.background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.rgb(8, 35, 100), Color.rgb(4, 13, 40))
        ).apply { cornerRadius = dp(24).toFloat(); setStroke(dp(1), Color.rgb(13, 76, 190)) }
        hero.addView(labelText("◷   SUIVEZ VOTRE UTILISATION", 13f, cyan, true))
        val heroTitle = labelText("Prenez le contrôle\nde votre téléphone", 24f, white, true)
        hero.addView(heroTitle)
        hero.addView(labelText("Découvrez vos habitudes et gagnez en contrôle.", 15f, muted))
        root.addView(hero)
        addSpace(16)

        if (!hasAccess()) {
            val permission = card()
            permission.addView(labelText("🔒  Autorisez l’accès", 19f, white, true))
            permission.addView(labelText(
                "Activez l’accès aux statistiques d’utilisation pour consulter votre historique.",
                14f, muted
            ))
            addSpaceInside(permission, 12)
            permission.addView(actionButton("⚙  Autoriser l’accès  ›") {
                startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            })
            root.addView(permission)
            addSpace(16)
            root.addView(labelText("Votre historique apparaîtra ici après autorisation.", 14f, muted))
            return
        }

        val nav = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(panel, Color.rgb(14, 62, 150))
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        val prev = actionButton("‹") { day -= 86400000L; render() }
        val next = actionButton("›") { day += 86400000L; render() }
        next.isEnabled = day < startOf(System.currentTimeMillis())
        val date = labelText(dateFmt.format(Date(day)).replaceFirstChar { it.uppercase() }, 16f, white, true)
        date.gravity = Gravity.CENTER
        nav.addView(prev, LinearLayout.LayoutParams(dp(48), dp(46)))
        nav.addView(date, LinearLayout.LayoutParams(0, -2, 1f))
        nav.addView(next, LinearLayout.LayoutParams(dp(48), dp(46)))
        root.addView(nav)
        addSpace(16)

        val sessions = loadSessions()
        if (sessions.isEmpty()) {
            val empty = card()
            empty.addView(labelText("Aucune activité enregistrée", 18f, white, true))
            empty.addView(labelText("Android ne conserve l’historique que sur une période limitée.", 14f, muted))
            root.addView(empty)
            return
        }

        val totals = HashMap<String, Long>()
        for (s in sessions) totals[s.pkg] = (totals[s.pkg] ?: 0L) + (s.end - s.start)
        val total = totals.values.sum()
        report = buildString {
            append("Journal du ${dateFmt.format(Date(day))}\n\n")
            append("Temps d'écran : ${dur(total)}\n\n")
            append("Applications les plus utilisées\n")
            for ((p, t) in totals.entries.sortedByDescending { it.value }.take(8)) {
                append("${label(p)} : ${dur(t)}\n")
            }
            append("\nChronologie\n")
            for (s in sessions) append("${hm.format(Date(s.start))} – ${hm.format(Date(s.end))}  ${label(s.pkg)} (${dur(s.end-s.start)})\n")
        }

        val totalCard = card()
        totalCard.addView(labelText("TEMPS D’ÉCRAN TOTAL", 13f, cyan, true))
        totalCard.addView(labelText(dur(total), 30f, white, true))
        totalCard.addView(labelText("Activité enregistrée pour cette journée", 13f, muted))
        root.addView(totalCard)
        addSpace(16)

        val appsCard = card()
        appsCard.addView(labelText("Statistiques", 20f, white, true))
        appsCard.addView(labelText("Applications les plus utilisées", 13f, muted))
        for ((p, t) in totals.entries.sortedByDescending { it.value }.take(8)) {
            val row = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(8), 0, dp(8))
            }
            row.addView(labelText(label(p), 15f, white, true), LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(labelText(dur(t), 14f, cyan, true))
            appsCard.addView(row)
        }
        root.addView(appsCard)
        addSpace(16)

        val timeline = card()
        timeline.addView(labelText("Chronologie", 20f, white, true))
        for (s in sessions) {
            timeline.addView(labelText(
                "${hm.format(Date(s.start))} – ${hm.format(Date(s.end))}\n${label(s.pkg)}  •  ${dur(s.end - s.start)}",
                14f, muted
            ))
        }
        root.addView(timeline)
        addSpace(16)

        root.addView(actionButton("Copier le rapport") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("rapport", report))
            Toast.makeText(this, "Rapport copié", Toast.LENGTH_SHORT).show()
        })
    }

    private fun addSpaceInside(parent: LinearLayout, height: Int) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }
}
